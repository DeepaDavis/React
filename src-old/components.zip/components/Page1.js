import React from 'react';
import './Page1.css';

const Page1 = () => {
  return (
    <>
      <div className='page1Container'>
          <h5 className='text1'>Gia & Guistina Jewellery</h5>

          <p className='text2'>
            <span>Your dream in </span>
            <br></br>
            <span>jewellery form</span>
          </p>

          <p className='head3'>
            <button className='btnn'>Learn More</button>
          </p>
      </div>

      
    </>
  );
};

export default Page1;
